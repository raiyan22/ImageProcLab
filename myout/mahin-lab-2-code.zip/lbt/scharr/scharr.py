import cv2 as cv
import matplotlib.pyplot as plt
import numpy as np
import math

path = 'C:/Users/Raiyan/Desktop/building_332x317.jpg'

img = cv.imread(path)
img = cv.cvtColor(img, cv.COLOR_BGR2GRAY)


kernel = np.array(([-3,0,3],
                   [-10,0,10],
                   [-3,0,3]), np.float32)

k_h = kernel.shape[0]
k_w = k_h
k_size = (k_h,k_w)

img_h = img.shape[0]
img_w = img.shape[1]
a = kernel.shape[0] // 2
b = kernel.shape[1] // 2
output = np.zeros((img_h,img_w), np.float32)

for i in range(img_h):
    for j in range(img_w):
        calc = 0
        for x in range(-a,a+1):
            for y in range(-b,b+1):
                if 0 <= i-x < img_h and 0 <= j-y < img_w:
                    calc += kernel[a+x][b+y] * img[i-x][j-y]
                else:
                    calc += 0
        calc = calc / (k_w*k_h)   
        output[i][j] = calc

scharr_vertical = output  
for i in range(img_h):
    for j in range(img_w):
            if scharr_vertical[i][j] > 255:
               scharr_vertical[i][j] = 255
            elif scharr_vertical[i][j] < 0:
                scharr_vertical[i][j] = 0

output = np.zeros((img_h,img_w), np.float32)

kernel = np.array(([-3,-10,-3],
                   [0,0,0],
                   [3,10,3]), np.float32)

for i in range(img_h):
    for j in range(img_w):
        calc = 0
        for x in range(-a,a+1):
            for y in range(-b,b+1):
                if 0 <= i-x < img_h and 0 <= j-y < img_w:
                    calc += kernel[a+x][b+y] * img[i-x][j-y]
                else:
                    calc += 0
        calc = calc / (k_w*k_h)  
        output[i][j] = calc                 

scharr_horizontal = output  
for i in range(img_h):
    for j in range(img_w):
            if scharr_horizontal[i][j] > 255:
               scharr_horizontal[i][j] = 255
            elif scharr_horizontal[i][j] < 0:
                scharr_horizontal[i][j] = 0

scharr_merged = scharr_horizontal + scharr_vertical
for i in range(img_h):
    for j in range(img_w):
            if scharr_merged[i][j] > 255:
               scharr_merged[i][j] = 255
            elif scharr_merged[i][j] < 0:
                scharr_merged[i][j] = 0

plt.imshow(scharr_merged, 'gray')
plt.show() 
    












        