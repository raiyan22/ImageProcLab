import cv2 as cv
import matplotlib.pyplot as plt
import numpy as np
import math

path = 'C:/Users/Raiyan/Desktop/building_332x317.jpg'

img = cv.imread(path)
img = cv.cvtColor(img, cv.COLOR_BGR2GRAY)

kernel = np.array(([-1,0,1],
                   [-1,0,1],
                   [-1,0,1]), np.float32)

k_h = kernel.shape[0]
k_w = k_h
k_size = (k_h,k_w)

img_h = img.shape[0]
img_w = img.shape[1]
a = kernel.shape[0] // 2
b = kernel.shape[1] // 2
output = np.zeros((img_h,img_w), np.float32)

for i in range(img_h):
    for j in range(img_w):
        calc = 0
        for x in range(-a,a+1):
            for y in range(-b,b+1):
                if 0 <= i-x < img_h and 0 <= j-y < img_w:
                    calc += kernel[a+x][b+y] * img[i-x][j-y]
                else:
                    calc += 0
        calc = calc / (k_w*k_h)   
        output[i][j] = calc

prewitt_vertical = output  
for i in range(img_h):
    for j in range(img_w):
            if prewitt_vertical[i][j] > 255:
               prewitt_vertical[i][j] = 255
            elif prewitt_vertical[i][j] < 0:
                prewitt_vertical[i][j] = 0

output = np.zeros((img_h,img_w), np.float32)

kernel = np.array(([-1,-1,-1],
                   [0,0,0],
                   [1,1,1]), np.float32)

for i in range(img_h):
    for j in range(img_w):
        calc = 0
        for x in range(-a,a+1):
            for y in range(-b,b+1):
                if 0 <= i-x < img_h and 0 <= j-y < img_w:
                    calc += kernel[a+x][b+y] * img[i-x][j-y]
                else:
                    calc += 0
        calc = calc / (k_w*k_h)  
        output[i][j] = calc                 

prewitt_horizontal = output  
for i in range(img_h):
    for j in range(img_w):
            if prewitt_horizontal[i][j] > 255:
               prewitt_horizontal[i][j] = 255
            elif prewitt_horizontal[i][j] < 0:
                prewitt_horizontal[i][j] = 0

prewitt_merged = prewitt_horizontal + prewitt_vertical
for i in range(img_h):
    for j in range(img_w):
            if prewitt_merged[i][j] > 255:
               prewitt_merged[i][j] = 255
            elif prewitt_merged[i][j] < 0:
                prewitt_merged[i][j] = 0

plt.imshow(prewitt_merged, 'gray')
plt.show() 
    












        